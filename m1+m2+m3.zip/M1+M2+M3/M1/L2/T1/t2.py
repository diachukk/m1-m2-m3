name = "Борис"
prof = "чарівник"
print("мене звати " + name + ".")
print("я - " + prof + ".")