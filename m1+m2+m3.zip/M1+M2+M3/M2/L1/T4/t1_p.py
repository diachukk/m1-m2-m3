a = input("Введіть число: ")
a = int(a)
if a < 0:
    a = -1 * a
print(a)