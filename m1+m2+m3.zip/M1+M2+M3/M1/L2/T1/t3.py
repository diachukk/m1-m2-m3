name = "Робот"
age = "2"
print("Я "+ name + ". Мені " + age + " років.")
my_name = input("А як тебе звати?")
print("Дуже приємно, " + my_name + ".")