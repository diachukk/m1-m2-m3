a ="Hello, "
b = "world!"
c = a + b
print(c)