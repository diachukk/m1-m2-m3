# Зробіть так, щоб програма надрукувала "How do you do?"
print('How do you do?')
