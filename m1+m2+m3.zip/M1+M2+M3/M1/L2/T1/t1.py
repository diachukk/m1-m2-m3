l = "I love "
s = "programming"
print (l + s)
s = "Python"
print (l + s)