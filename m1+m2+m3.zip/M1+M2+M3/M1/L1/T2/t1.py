#Зробіть так, щоб вийшла програма, яка пише "Hello, world!"
a = "Hello, "
b = "world!"
print(a + b)