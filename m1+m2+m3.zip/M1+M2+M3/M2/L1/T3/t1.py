a = input("Введіть число: ")
a = int(a)
a = 2 * a
if a > 8:
    a = a - 3
else:
    a = a +2
print(a)