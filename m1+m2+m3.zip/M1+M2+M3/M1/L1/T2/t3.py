#Зробіть так, щоб всі функції print запрацювали.
print ("Hello")
print ("What is your name?")
print ("I am Python!")
