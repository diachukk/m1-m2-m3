a = 0
a = "hello"
b = a
a = 14
print(a)
print(b)
#? що надрукує програма?
