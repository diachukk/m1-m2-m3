'''
#TODO Программа має надрукувати "This is Python. It’s cool! I really like programming! It’s cool!".

За допомогою аргумента format відформатуй рядок так, щоб він мав наступний вигляд:
'''

print("This is {}. It’s {}! I {} like programming! It’s {}!")
