a = int(input("Введіть число"))
if a > 0:
    print(str(a) + " - додатне число")
else:
    if a < 0:
        print(str(a) + " - від'ємне число!")
    else:
        print("Це нуль!")
print("До зустрічі!")