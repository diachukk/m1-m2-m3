x1 = 10
x2 = 12 - x1
x3 = x1 * x2
x2 = 5 * x2
x1 = x1 - x2
print(x1)
print(x2)
print(x3)
#? що надрукує програма?
