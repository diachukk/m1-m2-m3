'''
Введіть рядок s і число повторень рядків n. 
Виведіть рядок n раз за допомогою циклу.
'''

s=input("text:")
n=int(input("n:"))

for i in range(n):
    print(s)