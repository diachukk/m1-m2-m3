'''
Виправте помилки в програмі, щоб вона виводила такий текст:

we all live in a yellow submarine
yellow submarine,
yellow submarine
'''

s = "yellow submarine"
w = "we all live in a "
print(w + s)
print(s + ",")
print(s)