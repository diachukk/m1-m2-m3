name1 = input("Введіть ім'я")
name2 = input("Введіть прізвище: ")
print(name1 + " " + name2 + ".")