a = 9
b = 16
c = a + b
print(c)