name = input("What is your name? ")
answer = "Hello, " + name
print(answer)