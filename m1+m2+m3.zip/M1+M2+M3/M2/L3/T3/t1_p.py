a = int(input("Множник 1:"))
b = int(input("Множник 2:"))
answer = 0
for i in range(a):
    answer = answer + b
print(answer)