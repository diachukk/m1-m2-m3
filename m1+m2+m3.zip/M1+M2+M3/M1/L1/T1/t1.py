# Haшa пeршa пpoгpaмa
print("Hello, world!")
# Надрукуй привітання світу
print("Hello, world!")
