n = int(input("Введіть число: "))
i = 1
while i<=n:
    if i %2 == 0:
        print(i)
    i = i + 1